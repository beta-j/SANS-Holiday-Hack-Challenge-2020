#!/usr/bin/env python3
import random
from mt19937predictor import MT19937Predictor

predictor = MT19937Predictor()
file = open("outfile.txt", "r")
content =  file.readlines()

for line in range (0,1548):
    
    x = int(content[line])
    print (line, ": ",x)
    predictor.setrandbits(x, 64)

for i in range (129997, 130004):
  print (i,": ",predictor.getrandbits(64))
